<?php
/**
*	此文件是流程模块【officic.公文查阅】对应控制器接口文件。
*/ 
class mode_officicClassAction extends inputAction{
	
	public function storeafter($table, $rows)
	{
		return array(
			'isadd'    => false
		);
	}
}	
			