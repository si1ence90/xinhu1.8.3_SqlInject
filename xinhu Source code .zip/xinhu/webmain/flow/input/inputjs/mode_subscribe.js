//流程模块【subscribe.订阅】下录入页面自定义js页面,初始函数
function initbodys(){
	
}