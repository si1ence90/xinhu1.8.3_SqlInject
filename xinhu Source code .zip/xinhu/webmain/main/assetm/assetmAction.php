<?php
class assetmClassAction extends Action
{
	
}